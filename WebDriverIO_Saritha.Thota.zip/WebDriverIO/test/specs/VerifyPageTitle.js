const { commonUtils } = require('../../CommonUtils.js')


describe('Verify WebPage is displayed', () => {
    it('Verify Securuian Financial Retirement page is displayed', async () => {
        browser.maximizeWindow()
        browser.url(browser.config.baseUrl)
        await browser.waitUntil(
            async () => (await $("//h1[@class='dsg - h1']")),
            {
                timeout: 10000,
                timeoutMsg: 'expected text to be different after 5s'
            }
        );
        expect(browser).toHaveTitle("How Much to Save for Retirement | Securian Financial");
        browser.closeWindow()
    });
});

