var assert = require('assert');
require("../../CommonUtils.js");
const { scrollIntoView, takeScreenshot, getElement, enterText } = require("../../CommonUtils.js");

describe("Verify that the User can calculate the Retirement plan by submitting all the fields", () => {
    const screenshotsPath = "./test/Screenshots/AdjustDefaultValues_" + Math.round((new Date()).getTime() / 1000) + "/"
    it("User Fills all the fields", async () => {

        //Launch Broswer
        browser.url(browser.config.baseUrl)
        browser.maximizeWindow()

        //Get All Mandatory Fields
        let age_Txt = await getElement("Id", 'current-age')
        let retirementAge_Txt = await getElement("Id", 'retirement-age')
        let currentIncome_Txt = await getElement("Id", 'current-income')
        let spouseIncome_Txt = await getElement("Id", 'spouse-income')
        let currentTotalSavings_Txt = await getElement("Id", 'current-total-savings')
        let currentAnnualSavings_Txt = await getElement("Id", 'current-annual-savings')
        let savingsIncreaseRate_Txt = await getElement("Id", 'savings-increase-rate')

        //Enter values for all the mandatory fields
        await enterText(age_Txt, "40");
        await takeScreenshot(screenshotsPath, "AgeEntered")

        await enterText(retirementAge_Txt, "60");
        await takeScreenshot(screenshotsPath, "RetirementAgeEntered")

        await spouseIncome_Txt.click()
        await enterText(spouseIncome_Txt, "100000");
        await takeScreenshot(screenshotsPath, "SpouseIncomeEntered")

        await currentIncome_Txt.click()
        await enterText(currentIncome_Txt, "75000");
        await takeScreenshot(screenshotsPath, "CurrentAnnualIncomeEntered")

        await currentTotalSavings_Txt.click()
        await enterText(currentTotalSavings_Txt, "500000");
        await takeScreenshot(screenshotsPath, "CurrentSavingsEntered")

        await enterText(currentAnnualSavings_Txt, "10");
        await takeScreenshot(screenshotsPath, "CurrentAnnualSavingsEntered")

        await enterText(savingsIncreaseRate_Txt, "0.25");
        await takeScreenshot(screenshotsPath, "SavingsIncreaseEntered")

    });

    it("User Fills Additional fields", async () => {

        //Select Social Security Income
        let socialSecurityIncome_Radio_Btn = await getElement("Text", "label=Yes")
        socialSecurityIncome_Radio_Btn.click()
        await takeScreenshot(screenshotsPath, "SocialBenefitsSelected")

        //Select Marital Status
        let maritalStatus_Radio_Btn = await getElement("Text", "Married")
        maritalStatus_Radio_Btn.click()
        await takeScreenshot(screenshotsPath, "MaritalStatusSelected")

        //Select Social Security Override Amount
        let socialSecurityOverrideAmt_Txt = await getElement("Id", "social-security-override")
        await socialSecurityOverrideAmt_Txt.click()
        await enterText(socialSecurityOverrideAmt_Txt, "4000");
        await takeScreenshot(screenshotsPath, "SocialSecurityOverrideAmountEntered")

    });

    it("User Adjust Default values fields", async () => {

        //Click on Adjust Default Values
        let adjustDefaultValues_Lnk = await getElement("Text", "a=Adjust default values")
        adjustDefaultValues_Lnk.click()
        await takeScreenshot(screenshotsPath, "AdjustDefaultValuesClicked")

        //Select Retirement duration
        let retirementDuration_Txt = await getElement("Id", "retirement-duration")
        await enterText(retirementDuration_Txt, "20");
        await takeScreenshot(screenshotsPath, "RetirementDurationEntered")

        //Select Additional Income
        let additionalIncome_Txt = await getElement("Id", "additional-income")
        await additionalIncome_Txt.click()
        await enterText(additionalIncome_Txt, "500");
        await takeScreenshot(screenshotsPath, "AdditionalIncomeEntered")

        //Select Post Retirement Income
        let postRetirementIncome_Radio_Btn = await getElement("Xpath", "//input[@id='include-inflation']/following-sibling::label")
        postRetirementIncome_Radio_Btn.click()
        await takeScreenshot(screenshotsPath, "PostRetirementIncomeSelected")

        //Select Expected Inflation Rate
        let expectedInflationRate_Txt = await getElement("Id", "expected-inflation-rate")
        await expectedInflationRate_Txt.click()
        await enterText(expectedInflationRate_Txt, "5");
        await takeScreenshot(screenshotsPath, "ExpectedInflationRateEntered")

        //Select Retirement Annual Income
        let retirementAnnualIncome_Txt = await getElement("Id", "retirement-annual-income")
        await retirementAnnualIncome_Txt.click()
        await enterText(retirementAnnualIncome_Txt, "5000000");
        await takeScreenshot(screenshotsPath, "RetirementAnnualIncomeEntered")

        //Select Pre-Retirement ROI
        let preRetirementROI_Txt = await getElement("Id", "pre-retirement-roi")
        await preRetirementROI_Txt.click()
        await enterText(preRetirementROI_Txt, "8");
        await takeScreenshot(screenshotsPath, "PreRetirementROIEntered")

        //Select Post-Retirement ROI
        let postRetirementROI_Txt = await getElement("Id", "post-retirement-roi")
        await postRetirementROI_Txt.click()
        await enterText(postRetirementROI_Txt, "5");
        await takeScreenshot(screenshotsPath, "PostRetirementROIEntered")

        //Click on Save button
        let save_btn = await getElement("Text", 'button=Save changes')
        scrollIntoView(save_btn)
        await save_btn.click()
        await takeScreenshot(screenshotsPath, "ClickedOnSaveBtn")

        await browser.waitUntil(
            async () => (await $("//button[text()='Save changes']")),
            {
                timeout: 10000,
                timeoutMsg: 'expected text to be different after 5s'
            }
        );
        await takeScreenshot(screenshotsPath, "ValuesDefaulted")

    });


    it("User clicks on Calculate button", async () => {

        let calculate_btn = await getElement("Text", 'button=Calculate')
        scrollIntoView(calculate_btn)
        await calculate_btn.click()
        await takeScreenshot(screenshotsPath, "ClickedOnCalculateBtn")

    });

    it("Verify Results are displayed", async () => {

        await browser.waitUntil(
            async () => (await $("//h3[text()='Results']")),
            {
                timeout: 10000,
                timeoutMsg: 'expected text to be different after 5s'
            }
        );
        await takeScreenshot(screenshotsPath, "ResultsDisplayed")
        browser.closeWindow()
    });

});