var assert = require('assert');
require("../../CommonUtils.js");
const { scrollIntoView, takeScreenshot, getElement } = require("../../CommonUtils.js");

describe("Verify the Error Message 'Please fill out all required fields' is diplayed without submitting the mandatory fields", () => {
    const errorMsg = 'Please fill out all required fields'
    const screenshotsPath = "./test/Screenshots/VerifyErrorMsg_" + Math.round((new Date()).getTime() / 1000) + "/"
    it("Verify Error Message 'Please fill out all required fields' is diplayed", async () => {

        //Launch Broswer
        browser.url(browser.config.baseUrl)
        browser.maximizeWindow()

        //Click on Calcuulate button
        let calculate_btn = await getElement("Text", 'button=Calculate')
        scrollIntoView(calculate_btn)
        await calculate_btn.click()

        await takeScreenshot(screenshotsPath, "ClickedOnCalculateBtn")

        //Verify the error message is displayed and Text is expected
        let errorMsgElement = await getElement("Id", 'calculator-input-alert-desc')
        let actualErrorMsg = await errorMsgElement.getText()
        assert.equal(actualErrorMsg, errorMsg, "Error Message Mismatch")
        await takeScreenshot(screenshotsPath, "VerifyErrorMessage")
    });

    it("Verify Required Error Messages on Mandatory Fields", async () => {

        //Verify the error message is displayed for all the mandatory fields

        const errorMsg = "Input required"

        let ageErrorMsgElement = await getElement("Id", 'invalid-current-age-error')
        let retirementAgeMsgElement = await getElement("Id", 'invalid-retirement-age-error')
        let currentIncomeMsgElement = await getElement("Id", 'invalid-current-income-error')
        let currentTotalSavingsMsgElement = await getElement("Id", 'invalid-current-total-savings-error')
        let currentAnnualSavingsMsgElement = await getElement("Id", 'invalid-current-annual-savings-error')
        let savingsIncreaseRateMsgElement = await getElement("Id", 'invalid-savings-increase-rate-error')

        assert.equal(await ageErrorMsgElement.isDisplayed(), true, "Age Error Message is not displayed")
        assert.equal(errorMsg, await ageErrorMsgElement.getText(), "Age Error Message is not displayed")

        assert.equal(await retirementAgeMsgElement.isDisplayed(), true, "Retirement Age Error Message is not displayed")
        assert.equal(errorMsg, await retirementAgeMsgElement.getText(), "Retirement Age Error Message is not displayed")

        assert.equal(await currentIncomeMsgElement.isDisplayed(), true, "Current Income Error Message is not displayed")
        assert.equal(errorMsg, await currentIncomeMsgElement.getText(), "Current Income Error Message is not displayed")

        assert.equal(await currentTotalSavingsMsgElement.isDisplayed(), true, "Current Total Savings Error Message is not displayed")
        assert.equal(errorMsg, await currentTotalSavingsMsgElement.getText(), "Current Total Savings Error Message is not displayed")

        assert.equal(await currentAnnualSavingsMsgElement.isDisplayed(), true, "Current Annual Savings Error Message is not displayed")
        assert.equal(errorMsg, await currentAnnualSavingsMsgElement.getText(), "Current Annual Savings Error Message is not displayed")

        assert.equal(await savingsIncreaseRateMsgElement.isDisplayed(), true, "Savings Increase Error Message is not displayed")
        assert.equal(errorMsg, await savingsIncreaseRateMsgElement.getText(), "Savings Increase Error Message is not displayed")
        
        await takeScreenshot(screenshotsPath, "VerifyRequiredErrorMessage")

        browser.closeWindow()
    });


});