var assert = require('assert');
require("../../CommonUtils.js");
const { scrollIntoView, takeScreenshot, getElement, enterText } = require("../../CommonUtils.js");

describe("Verify that the User can calculate the Retirement plan by submitting all the mandatory fields", () => {
    const screenshotsPath = "./test/Screenshots/RetirementCalc_MandatoryFields_" + Math.round((new Date()).getTime() / 1000) + "/"
    it("User Fills all the mandatory fields", async () => {

        //Launch Broswer
        browser.url(browser.config.baseUrl)
        browser.maximizeWindow()

        //Get All Mandatory Fields
        let age_Txt = await getElement("Id", 'current-age')
        let retirementAge_Txt = await getElement("Id", 'retirement-age')
        let currentIncome_Txt = await getElement("Id", 'current-income')
        let currentTotalSavings_Txt = await getElement("Id", 'current-total-savings')
        let currentAnnualSavings_Txt = await getElement("Id", 'current-annual-savings')
        let savingsIncreaseRate_Txt = await getElement("Id", 'savings-increase-rate')

        //Enter values for all the mandatory fields
        await enterText(age_Txt, "40");
        await takeScreenshot(screenshotsPath, "AgeEntered")

        await enterText(retirementAge_Txt, "60");
        await takeScreenshot(screenshotsPath, "RetirementAgeEntered")

        await currentIncome_Txt.click()
        await enterText(currentIncome_Txt, "100000");
        await takeScreenshot(screenshotsPath, "CurrentAnnualIncomeEntered")

        await currentTotalSavings_Txt.click()
        await enterText(currentTotalSavings_Txt, "500000");
        await takeScreenshot(screenshotsPath, "CurrentSavingsEntered")

        await enterText(currentAnnualSavings_Txt, "10");
        await takeScreenshot(screenshotsPath, "CurrentAnnualSavingsEntered")

        await enterText(savingsIncreaseRate_Txt, "0.25");
        await takeScreenshot(screenshotsPath, "SavingsIncreaseEntered")
        
    });

    it("User Fills Additional fields", async () => {

        //Select Social Security Income
        let socialSecurityIncome_Radio_Btn = await getElement("Text", "label=Yes")
        socialSecurityIncome_Radio_Btn.click()
        await takeScreenshot(screenshotsPath, "SocialBenefitsSelected")

        //Select Marital Status
        let maritalStatus_Radio_Btn = await getElement("Text", "Married")
        maritalStatus_Radio_Btn.click()
        await takeScreenshot(screenshotsPath, "MaritalStatusSelected")

        //Select Social Security Override Amount
        let socialSecurityOverrideAmt_Txt = await getElement("Id", "social-security-override")
        await socialSecurityOverrideAmt_Txt.click()
        await enterText(socialSecurityOverrideAmt_Txt, "4000");
        await takeScreenshot(screenshotsPath, "SocialSecurityOverrideAmountEntered")

    });

    it("User clicks on Calculate button", async () => {

        let calculate_btn = await getElement("Text", 'button=Calculate')
        scrollIntoView(calculate_btn)
        await calculate_btn.click()
        await takeScreenshot(screenshotsPath, "ClickedOnCalculateBtn")

    });

    it("Verify Results are displayed", async () => {

        await browser.waitUntil(
            async () => (await $("//h3[text()='Results']")),
            {
                timeout: 10000,
                timeoutMsg: 'expected text to be different after 5s'
            }
        );
        await takeScreenshot(screenshotsPath, "ResultsDisplayed")
        browser.closeWindow()
    });

});