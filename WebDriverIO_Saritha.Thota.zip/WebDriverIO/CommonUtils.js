// JavaScript source code

var fs = require('fs');

module.exports = {

    getElementAttributeValue: async function getElementAttributeValue(element, attribute) {
        return element.getAttribute(attribure);
    },

    waitTillElementIsVisible: async function waitTillElementIsVisible(element, waitDurationInMilliSeconds) {
        let elem = await $(element)
        await elem.waitForDisplayed({ timeout: waitDurationInMilliSeconds });
    },

    takeScreenshot: async function takeScreenshot(path, fileName) {
        if (!fs.existsSync(path)) {
            fs.mkdirSync(path);
        }
        await browser.saveScreenshot(path + fileName + ".png")
    },

    scrollIntoView: async function scrollIntoView(element) {
        let xLocation = element.getLocation('x')
        let yLocation = element.getLocation('y')
        await element.moveTO({ xLocation }, { yLocation });
    },

    getElement: async function getElement(type, expression) {
        switch (type) {
            case "Text":
                return await $(expression)
                break;
            case "Id":
                return await $('#' + expression)
                break;
            case "Xpath":
                return await $(expression)
                break;
        }
    },

    clearValue: async function clearValue(element) {
        await element.clearValue();
    },

    enterText: async function enterText(element, text) {
        await element.clearValue();
        await element.setValue(text)
    }

};
